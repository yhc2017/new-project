<!DOCTYPE html>
<html>

	<head lang="en">
		<meta charset="UTF-8">
		<title>研究成果</title>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1.0, user-scalable=0,user-scalable=no">
		<meta name="format-detection" content="telephone=no">
		<meta name="renderer" content="webkit">
		<meta http-equiv="Cache-Control" content="no-siteapp" />
		<link rel="alternate icon" type="img/hengwang-1.png" href="img/hengwang-1.png">
		<link rel="stylesheet" href="css/amazeui.css" />
		<link rel="stylesheet" href="css/style.css" />
	</head>

	<body>
		<?php include ("header.php");?>
		<div class="toppic" style="margin-top: 80px;">
			<div class="am-container-1">
				<div class="toppic-title left">
					<i class="am-icon-dropbox toppic-title-i"></i>
					<span class="toppic-title-span">研究成果</span>
					<p>RESEARCH RESULT</p>
				</div>
				<div class="right toppic-progress">
					<span><a href="index.php" class="w-white">首页</a></span>
					<i class=" am-icon-arrow-circle-right w-white"></i>
					<span><a href="achievement.php" class="w-white">研究成果</a></span>
				</div>
			</div>
		</div>

		<div class="am-u-sm-0 am-u-md-0 am-u-lg-2" style="margin-left: 100px;">
        <div data-am-widget="titlebar" class="am-titlebar am-titlebar-default">
            <h2 class="am-titlebar-title ">
                前往
            </h2>
        </div>
        <div data-am-widget="list_news" class="am-list-news am-list-news-default right-bg">
            <ul class="am-list"  >
                <li class="am-g am-list-item-desced am-list-item-thumbed am-list-item-thumb-left" style="background-color: #0099FF;">
                    <div class=" am-u-sm-8" >
                        <h3 class="am-list-item-hd"><a href="achievement.php">成果介绍</a></h3>
                    </div>
                </li>
                <li class="am-g am-list-item-desced am-list-item-thumbed am-list-item-thumb-left">
                    <div class=" am-u-sm-8">
                        <h3 class="am-list-item-hd"><a href="achievement2.php">成果展示</a></h3>
                    </div>
                </li>
            </ul>
        </div>
       </div>
		
		<div class="am-g am-container" style="margin-top: 50px;">
    		<div class="am-u-sm-5 am-u-md-10 am-u-lg-9">
    			<div>
    				<div align="center"><h1>成果介绍</h1></div>
    				<hr data-am-widget="divider" style="" class="am-divider am-divider-dashed" />
    			</div>
    		</div>
    	</div>
	

		<?php include ("footer_dome.php");?>

	</body>
	<!--[if lt IE 9]>
<script src="http://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
<script src="http://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
<script src="assets/js/amazeui.ie8polyfill.min.js"></script>
<![endif]-->

	<!--[if (gte IE 9)|!(IE)]><!-->
	<script src="js/jquery.min.js"></script>
	<!--<![endif]-->
	<script src="js/amazeui.min.js"></script>

</html>