<?php
/**
 * Created by PhpStorm.
 * User: hasee
 * Date: 2017/10/2
 * Time: 2:01
 */
//echo "dad";
//<?php
echo $_SERVER["SERVER_SOFTWARE"]  ;
?>