
<footer class="footer">
	<ul>
		<li class="am-u-lg-6 am-u-md-6 am-u-sm-12 part-5-li2">
			<div class="part-5-title">联系我们</div>
			<div class="part-5-words2">
				<span>广东省广州市从化区经济开发区高技术产业园广从南路548号</span>
				<span>
					电话：020－87818918 
					传真：87818020  
					邮编：510990</span>
				<span></span>
			</div>
		</li>
		<li class="am-u-lg-4 am-u-md-4 am-u-sm-12 ">
			<div class="part-5-title">合作单位</div>
			<div class="part-5-words2">
				<ul class="part-5-words2-ul">
					<!--<li class="am-u-lg-4 am-u-md-6 am-u-sm-4">
						<a href="http://www.sise.com.cn/">华软官网</a>
					</li>
					<li class="am-u-lg-4 am-u-md-6 am-u-sm-4">
						<a href="http://home.sise.cn/">华软导航</a>
					</li>
					<li class="am-u-lg-4 am-u-md-6 am-u-sm-4">
						<a href="http://soft.sise.cn/">软件工程系官网</a>
					</li>
					<li class="am-u-lg-4 am-u-md-6 am-u-sm-4">
						<a href="about-us.html">关于我们</a>
					</li>-->
					<div class="clear"></div>
				</ul>
			</div>
		</li>
		<div class="clear"></div>
	</ul>

</footer>