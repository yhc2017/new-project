<header class="am-topbar header">
	<div class="am-container-1">
		<div class="left hw-logo">
			<img class=" logo" src="img/logo.png"></img>
		</div>
		<button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#doc-topbar-collapse'}"><span class="am-sr-only">导航切换</span> <span
  class="am-icon-bars"></span></button>

		<div class="am-collapse am-topbar-collapse right" id="doc-topbar-collapse">

			<div class=" am-topbar-left am-form-inline am-topbar-right" role="search">
				<ul class="am-nav am-nav-pills am-topbar-nav hw-menu">
					<li>
						<a href="index.php">首页</a>
					</li>
					<li>
						<a href="general-profile.php">研究所概况</a>
					</li>
					<li>
						<a href="news.php">新闻动态 </a>
					</li>
					<li>
						<a href="achievement.php">研究成果</a>
					</li>
					<li>
						<a href="open-exchange.php">开放交流</a>
					</li>
					<li>
						<a href="technology-frontier.php">技术前沿</a>
					</li>
				</ul>
			</div>

		</div>
	</div>
</header>