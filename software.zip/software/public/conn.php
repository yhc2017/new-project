<?php
$conn=mysqli_connect("localhost","root","123456","news3") or die("connection error".mysql_error());
mysqli_query($conn,"set names utf8");
?>
